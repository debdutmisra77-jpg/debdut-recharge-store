require("dotenv").config();
const express = require("express");
const path = require("path");
const sqlite3 = require("sqlite3").verbose();
const app = express();
const db = new sqlite3.Database(process.env.DB_PATH || "./store.db");
app.use(express.json());
app.use(express.urlencoded({extended:true}));
app.use(express.static(path.join(__dirname,"public")));
db.run(`CREATE TABLE IF NOT EXISTS orders (
 id INTEGER PRIMARY KEY AUTOINCREMENT, customer_name TEXT, mobile TEXT,
 service TEXT, operator TEXT, amount REAL, status TEXT DEFAULT 'created',
 created_at TEXT DEFAULT CURRENT_TIMESTAMP
)`);
app.get("/api/health",(_req,res)=>res.json({
 ok:true, store:process.env.STORE_NAME||"DEBDUT RECHARGE STORE",
 payuConfigured:Boolean(process.env.PAYU_KEY&&process.env.PAYU_SALT),
 fulfilmentEnabled:process.env.RECHARGE_FULFILMENT_ENABLED==="true"
}));
app.post("/api/orders",(req,res)=>{
 const b=req.body||{}, name=String(b.customer_name||"").trim().slice(0,80);
 const mobile=String(b.mobile||"").trim().slice(0,20);
 const service=String(b.service||""), operator=String(b.operator||"").trim().slice(0,50);
 const amount=Number(b.amount);
 if(!name||!/^[0-9+ -]{8,15}$/.test(mobile)||!["mobile","dth","gaming"].includes(service)||!operator||!Number.isFinite(amount)||amount<1||amount>50000)
  return res.status(400).json({error:"Please check the order details."});
 db.run("INSERT INTO orders(customer_name,mobile,service,operator,amount) VALUES(?,?,?,?,?)",
 [name,mobile,service,operator,amount],function(err){
  if(err)return res.status(500).json({error:"Could not create order."});
  res.status(201).json({orderId:this.lastID,status:"created",message:"Demo order only. Payment and recharge are disabled."});
 });
});
app.get("/api/orders/:id",(req,res)=>db.get(
 "SELECT id,service,operator,amount,status,created_at FROM orders WHERE id=?",
 [Number(req.params.id)],(err,row)=>{if(err)return res.status(500).json({error:"Lookup failed."});if(!row)return res.status(404).json({error:"Order not found."});res.json(row);}
));
app.post("/payu/success",(_req,res)=>res.status(501).send("PayU callback not configured. Live payments disabled."));
app.post("/payu/failure",(_req,res)=>res.status(501).send("PayU callback not configured. Live payments disabled."));
const port=process.env.PORT||3000;
app.listen(port,()=>console.log("DEBDUT RECHARGE STORE running on "+port));
