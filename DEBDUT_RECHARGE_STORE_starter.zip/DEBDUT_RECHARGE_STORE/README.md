# DEBDUT RECHARGE STORE — starter
This is a development starter, not a deployed production store.

## Run
Install Node.js 20+, run `npm install`, copy `.env.example` to `.env`, set a strong private `ADMIN_TOKEN`, then run `npm start`.

## Important
- GitHub Pages can host only the static `public` files. It cannot run this Node.js backend or SQLite database.
- This project requires a Node.js host and persistent database storage for the full-stack version.
- PayU checkout and callbacks are not implemented. Keep real payments disabled.
- No recharge provider is integrated. Keep actual fulfilment disabled.
- Before launch, implement PayU hash verification, webhook verification, Verify Payment API reconciliation, idempotency, secure admin authentication, HTTPS, monitoring and backups.
- Obtain a written recharge provider agreement and operator routing evidence, especially for Jio.
- Complete and review genuine business, contact, privacy, terms and refund information.
- Never upload `.env`, PayU Salt, passwords, OTPs or other secrets to GitHub.
