# DEBDUT RECHARGE STORE — starter

This is a **development starter**, not a deployed or production-ready recharge business.

## Run locally
1. Install Node.js 20 or newer.
2. Extract this ZIP and open a terminal in this folder.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Set a long random `ADMIN_TOKEN`. Leave PayU credentials blank for now.
6. Run `npm start` and open `http://localhost:3000`.

## Important launch blockers
- No recharge API provider is contracted or integrated.
- PayU checkout is not implemented or enabled in this starter. Callback endpoints deliberately return 501.
- Do not accept real payments or claim a recharge is complete.
- Before PayU launch, implement request signing, response hash verification, webhook verification, Verify Payment API reconciliation, idempotency and secure order mapping according to current PayU documentation.
- Replace the temporary admin-token endpoint with proper authenticated admin access, role checks, rate limiting and audit logs.
- Add validation, logging, monitoring, backups, HTTPS, persistent database storage and production error handling.
- Complete and review Terms, Privacy and Refund pages, and publish genuine business/contact details.
- Obtain written operator authorization/routing evidence from the recharge provider, especially for Jio.
- SQLite on many ephemeral hosting plans loses data on restart/redeploy unless persistent storage is configured. Choose a persistent database/storage plan.

## Hosting
Use a Node.js-capable host with HTTPS and persistent database storage. Configure environment variables in the host dashboard. Never commit `.env`, expose PayU Salt, or put secrets in browser code.

## Safety defaults
`RECHARGE_FULFILMENT_ENABLED=false` and PayU credentials are blank. Keep real payments and fulfilment disabled until all checks and end-to-end tests pass.
