require("dotenv").config();
const express = require("express");
const path = require("path");
const crypto = require("crypto");
const sqlite3 = require("sqlite3").verbose();

const app = express();
const PORT = process.env.PORT || 3000;
const db = new sqlite3.Database(process.env.DB_PATH || "./store.db");

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_name TEXT NOT NULL,
    mobile TEXT NOT NULL,
    service TEXT NOT NULL,
    operator TEXT NOT NULL,
    amount REAL NOT NULL,
    status TEXT NOT NULL DEFAULT 'created',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
  )`);
});

const safeText = (v, max=100) => String(v || "").trim().slice(0, max);

app.get("/api/health", (_req, res) => {
  res.json({
    ok: true,
    store: process.env.STORE_NAME || "DEBDUT RECHARGE STORE",
    paymentsConfigured: Boolean(process.env.PAYU_KEY && process.env.PAYU_SALT),
    payuMode: process.env.PAYU_MODE || "test",
    fulfilmentEnabled: process.env.RECHARGE_FULFILMENT_ENABLED === "true"
  });
});

app.post("/api/orders", (req, res) => {
  const customer_name = safeText(req.body.customer_name, 80);
  const mobile = safeText(req.body.mobile, 20);
  const service = safeText(req.body.service, 20);
  const operator = safeText(req.body.operator, 40);
  const amount = Number(req.body.amount);

  if (!customer_name || !/^[0-9+ -]{8,15}$/.test(mobile) ||
      !["mobile", "dth", "gaming"].includes(service) ||
      !operator || !Number.isFinite(amount) || amount < 1 || amount > 50000) {
    return res.status(400).json({ error: "Please check the order details." });
  }

  db.run(
    `INSERT INTO orders (customer_name, mobile, service, operator, amount)
     VALUES (?, ?, ?, ?, ?)`,
    [customer_name, mobile, service, operator, amount],
    function(err) {
      if (err) return res.status(500).json({ error: "Could not create order." });
      res.status(201).json({
        orderId: this.lastID,
        status: "created",
        message: "Order created. Payment is not enabled in this starter."
      });
    }
  );
});

app.get("/api/orders/:id", (req, res) => {
  db.get("SELECT id, service, operator, amount, status, created_at FROM orders WHERE id = ?",
    [Number(req.params.id)], (err, row) => {
      if (err) return res.status(500).json({ error: "Could not look up order." });
      if (!row) return res.status(404).json({ error: "Order not found." });
      res.json(row);
    });
});

// Development-only admin status endpoint. Replace with proper authenticated admin access
// before deployment. Do not expose ADMIN_TOKEN in frontend code.
app.post("/api/admin/orders/:id/status", (req, res) => {
  const token = req.get("x-admin-token");
  if (!process.env.ADMIN_TOKEN || token !== process.env.ADMIN_TOKEN) {
    return res.status(401).json({ error: "Unauthorized." });
  }
  const status = safeText(req.body.status, 30);
  if (!["created", "pending", "paid", "failed", "refunded", "fulfilled"].includes(status)) {
    return res.status(400).json({ error: "Invalid status." });
  }
  db.run("UPDATE orders SET status = ? WHERE id = ?", [status, Number(req.params.id)], function(err) {
    if (err) return res.status(500).json({ error: "Update failed." });
    if (!this.changes) return res.status(404).json({ error: "Order not found." });
    res.json({ ok: true });
  });
});

// PayU callbacks are intentionally not activated. A production integration must implement
// signature/hash verification, webhook handling, Verify Payment API reconciliation,
// idempotency, and secure order-to-payment mapping before accepting real payments.
app.post("/payu/success", (_req, res) => {
  res.status(501).send("PayU callback is not configured. Do not accept live payments yet.");
});
app.post("/payu/failure", (_req, res) => {
  res.status(501).send("PayU callback is not configured. Do not accept live payments yet.");
});

app.listen(PORT, () => console.log(`DEBDUT RECHARGE STORE starter running on port ${PORT}`));
