const orderForm = document.querySelector("#orderForm");
orderForm.addEventListener("submit", async (e) => {
  e.preventDefault();
  const message = document.querySelector("#message");
  message.textContent = "Creating order...";
  const data = Object.fromEntries(new FormData(orderForm).entries());
  data.amount = Number(data.amount);
  try {
    const r = await fetch("/api/orders", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)});
    const result = await r.json();
    if (!r.ok) throw new Error(result.error || "Request failed");
    message.textContent = `Demo order #${result.orderId} created. ${result.message}`;
    orderForm.reset();
  } catch (err) { message.textContent = err.message; }
});
document.querySelector("#trackForm").addEventListener("submit", async (e) => {
  e.preventDefault();
  const id = new FormData(e.currentTarget).get("id");
  const out = document.querySelector("#tracking");
  try {
    const r = await fetch(`/api/orders/${encodeURIComponent(id)}`);
    const result = await r.json();
    if (!r.ok) throw new Error(result.error || "Not found");
    out.textContent = JSON.stringify(result, null, 2);
  } catch (err) { out.textContent = err.message; }
});